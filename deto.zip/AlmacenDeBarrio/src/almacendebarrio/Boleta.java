package almacendebarrio;

/**
 *
 * @author profe Oscar
 */
public class Boleta {
    private int numero;
    private String fecha;
    private long monto;
    private String metodoPago;
    //constructor
    public Boleta(int numero, String fecha, long monto, String metodoPago){
        this.setNumero(numero);
        this.setFecha(fecha);
        this.setMonto(monto);
        this.setMetodoPago(metodoPago);      
    }
    //Getters y setters (accesor)
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        if(numero > 0){
            this.numero = numero;
        }
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public long getMonto() {
        return monto;
    }

    public void setMonto(long monto) {
        if(monto > 0){
            this.monto = monto;
        }
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }
    
}






