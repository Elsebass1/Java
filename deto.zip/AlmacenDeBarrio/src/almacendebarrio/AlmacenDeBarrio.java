package almacendebarrio;

/**
 *
 * @author CETECOM
 */
public class AlmacenDeBarrio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
