package almacendebarrio;

public class Factura {
    //atributos
    private long numFactura;
    private String fechaEmision;
    private long total;
    private String fechaVencimiento;
    private int consumo;
    
    //constructor
    public Factura(long numFactura, String fechaEmision, long total, String fechaVencimiento, int consumo) {
        this.setNumFactura(numFactura);
        this.setFechaEmision(fechaEmision);
        this.setTotal(total);
        this.setFechaVencimiento(fechaVencimiento);
        this.setConsumo(consumo);
    }
//metodos get y set 
    public long getNumFactura() {
        return numFactura;
    }

    public void setNumFactura(long numFactura) {
        this.numFactura = numFactura;
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        if (total > 0)
            this.total = total;
    }

    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(String fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public int getConsumo() {
        return consumo;
    }

    public void setConsumo(int consumo) {
        if (consumo >= 0)
            this.consumo = consumo;
    }

    //customer
    public calcularMontoFinal(float valorKW){
        long totalFactura; 
        totalFactura = valorKW * this.consumo;
        this.setTotal(totalFactura);
        return totalFactura;
        
        
    }
    
}
